function nCluster = indicateCluster(Block,clusters)

v = Block(:)';

for i=1:length(clusters)
    
    a = ones(size(clusters{i},1),1);
    for j=1:length(v)
        a = (v(j) == clusters{i}(:,j)) & a;
        if(a==0)
            break;
        end
    end
    
    if(max(a) == 1)
        nCluster = i;
        break;
    end
end    

end