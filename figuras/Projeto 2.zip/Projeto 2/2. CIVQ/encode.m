function bitstream = encode(qBlocks,codeBook,L,M)

codeBook_matrix = zeros(length(codeBook),L);
for i = 1:length(codeBook)
    codeBook_matrix(i,1:end) = codeBook{i}';
end

bitstream = repmat('0',[1,M*L*8 + length(qBlocks)*(log2(M))]);

i=1;
for z = 1:length(codeBook)
    
    p = codeBook{z}(:);
    for j=1:length(p)
        bitstream(1,i:i+7) = dec2bin(p(j),8);
        i = i+8;
    end
end

k=1;

while(k<=length(qBlocks))
    
    n = indicateCodeVector(qBlocks{k},codeBook_matrix);
    bitstream(1,i:i+log2(M)-1) = dec2bin(n-1,log2(M)); 
    i = i+log2(M);
    k=k+1;
    
end

end