function [codeBook,clusters] = trainCodebook(trainingVecs_cell,trainingVecs_matrix,M,L,codeBook,clusters)

codeBook1 = codeBook;
dist1 = 100;
dist2 = 1;
i=1;
while(i<100)
   [dist1,distPerVector] = calculateDistortionFromClusters(clusters,codeBook,M);
    if(abs(dist1 - dist2)<=0.1)
        break;
    end
    
    for j=1:M
        codeBook1{j} = calculateMeanVector(clusters{j}); %calcula cada codevector como a media da cluster anterior
    end
    
    clusters = getClusters(codeBook1,trainingVecs_cell,trainingVecs_matrix,L); %determina a clusters com o codeBook novo
    
    codeBook = codeBook1;
    [dist2,distPerVector] = calculateDistortionFromClusters(clusters,codeBook,M);
    
    i = i+1;
end

end