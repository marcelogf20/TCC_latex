function nCodeVector = indicateCodeVector_v2(Block,codeBook_matrix,L)

v = Block(:)';
a = ones(size(codeBook_matrix,1),L);

for i=1:L
    a(:,i) = v(i);
end

dist = sum((a-codeBook_matrix).^2,2);
    
[Y,I] = min(dist);

nCodeVector = I;


end