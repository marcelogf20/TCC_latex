function [initialCodebook,clusters] = getInitialCodebook(trainingVecs_cell,trainingVecs_matrix,M,L)

codeBook = cell(1,1);
meanVector = calculateMeanVector(trainingVecs_matrix);
codeBook{1} = meanVector;

while(length(codeBook) < M)
    
    for j=1:length(codeBook)
        r = randi([-5 5],L,1);
        newCodeVector = codeBook{j} + r;
        newCodeVector(newCodeVector < 0) = 0;   %garante que o newCodeVector n�o est� fora do range de uma imagem
        newCodeVector(newCodeVector > 255) = 255;   %garante que o newCodeVector n�o est� fora do range de uma imagem
        codeBook = [codeBook;newCodeVector];
    end
    
    clusters = getClusters(codeBook,trainingVecs_cell,trainingVecs_matrix,L);
        
    codeBook = getNewCodeBookFromClusters(clusters,L);
    
end

initialCodebook = codeBook;
clusters = getClusters(codeBook,trainingVecs_cell,trainingVecs_matrix,L);

end