function codeBook = getNewCodeBookFromClusters(clusters,L)

codeBook = cell(1,1);
meanVector = calculateMeanVector(clusters{1});
codeBook{1} = meanVector;

for i=2:length(clusters)
    
    meanVector = calculateMeanVector(clusters{i});
    codeBook = [codeBook meanVector];
end

codeBook = codeBook';

end