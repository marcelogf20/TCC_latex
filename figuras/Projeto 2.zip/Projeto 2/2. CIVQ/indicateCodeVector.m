function n = indicateCodeVector(Block,codeBook_matrix)

v = Block(:)';
    
a = ones(size(codeBook_matrix,1),1);
for j=1:length(v)
    a = (v(j) == codeBook_matrix(:,j)) & a;
    if(a==0)
        break;
    end
end

[Y,n] = max(a);
    

end