function Blocks = getBlocks(N,img)  %essa fun��o gera os blocos que ser�o quantizados

nBlocks = ceil((size(img,1)*size(img,2))/(N^2));
Blocks = cell(nBlocks,1);

i=1;
j=1;
k=1;

while(i <= nBlocks)
    
    while(k+N-1 <= size(img,2))
        Blocks{i} = img(j:j+(N-1),k:k+(N-1));
        k = k+N;
        i = i+1;
    end
    
    j = j+N;
    k = 1;
end

end