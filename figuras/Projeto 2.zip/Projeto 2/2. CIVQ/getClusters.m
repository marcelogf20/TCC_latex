function clusters = getClusters(codeBook,trainingVecs_cell,trainingVecs_matrix,L)

clusters = cell(1,length(codeBook)); %em cada matriz dessa cell, cada linha � um vetor de treinamento

for i=1:length(clusters)
    clusters{i} = ones(size(trainingVecs_matrix))*-1;   %inicializa cada matriz com todos elementos -1
end

dist = [];

for i=1:length(codeBook)
    
    aux = ones(size(trainingVecs_matrix));

    for j=1:size(aux,2)
        aux(:,j) = aux(:,j)*codeBook{i}(j);
    end
    
    dist = [dist sum((((aux - trainingVecs_matrix)).^2),2)];
end

count = zeros(length(clusters),1);

for i=1:size(dist,1)
    [Y,I] = min(dist(i,:));
    count(I) = count(I) + 1;
    clusters{I}(count(I),1:L) = trainingVecs_cell{i}';
end

for i=1:length(clusters)
    clusters{i} = clusters{i}(1:count(i),:);
    if(isempty(clusters{i}))
        clusters{i} = codeBook{i}';
    end
end

end