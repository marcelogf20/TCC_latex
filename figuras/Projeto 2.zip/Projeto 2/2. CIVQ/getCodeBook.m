function [codeBook,clusters] = getCodeBook(Blocks,L,M)

trainingVecs_cell = cell(1,length(Blocks));
trainingVecs_matrix = zeros(length(Blocks),L); %cada linha � um codevector


for i=1:length(Blocks)
    trainingVecs_cell{i} = Blocks{i}(:);
    trainingVecs_matrix(i,1:L) = (Blocks{i}(:))';
end

[codeBook,clusters] = getInitialCodebook(trainingVecs_cell,trainingVecs_matrix,M,L);

[codeBook,clusters] = trainCodebook(trainingVecs_cell,trainingVecs_matrix,M,L,codeBook,clusters);

end