function [out,m,n,M,L] = readBitstreamFromFile(filename)

fid = fopen(filename,'rb');

m = fread(fid,1,'uint16');
n = fread(fid,1,'uint16');
M = fread(fid,1,'uint16');
L = fread(fid,1,'uint8');
bitstream = fread(fid,'uint8');

fclose(fid);

out = [];
for i=1:length(bitstream)
    out = [out dec2bin(bitstream(i),8)];
end

end