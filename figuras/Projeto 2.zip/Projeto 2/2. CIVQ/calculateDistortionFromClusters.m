function [dist,distPerVector] = calculateDistortionFromClusters(clusters,codeBook,M)

dist = [];

for i=1:length(clusters)
    
    aux = ones(size(clusters{i}));

    for j=1:size(aux,2)
        aux(:,j) = aux(:,j)*codeBook{i}(j);
    end
    
    dist = [dist sum(sum(((aux - clusters{i}).^2),2))];
    
end
a = 0;
for i=1:M
    distPerVector(1,i) = dist(i)/size(clusters{i},1);
    a = size(clusters{i},1)+a;
end
dist = sum(dist)/a;
end