function meanVector = calculateMeanVector(Vecs) %Vecs � uma matriz em que cada linha � um vetor

meanVector = (sum(Vecs,1)/size(Vecs,1))';

end