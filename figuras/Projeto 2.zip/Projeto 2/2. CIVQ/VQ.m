function qBlocks = VQ(Blocks,codeBook,clusters,m,n,L)

qBlocks = cell(size(Blocks));
codeBook_matrix = zeros(length(codeBook),L);

for i=1:length(codeBook)
    codeBook_matrix(i,1:L) = (codeBook{i}(:))';
end

for i=1:length(Blocks)
    nCodeVector = indicateCodeVector_v2(Blocks{i},codeBook_matrix,L);
    %nCluster = indicateCluster(Blocks{i},clusters);
    qBlocks{i} = codeBook{nCodeVector};
end


end