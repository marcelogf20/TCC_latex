function value = PSNR(iimg,qimg)

value = 10*log10((2^8 -1)^2/MSE(iimg,qimg));

end