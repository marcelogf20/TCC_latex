function qvalue = getqValue(xmin,xmax,limits) 


limits = limits(2:end-1);
limits = [xmin limits xmax];
a = length(limits);

for i=1:a-1
    qvalue(i,1) = (limits(i) + limits(i+1))/2;
end    
qvalue = round(qvalue);
end