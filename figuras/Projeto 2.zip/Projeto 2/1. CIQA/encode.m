function bitstream = encode(M,N,Blocks,qBlocks)

aux = permn([0;1],log2(M));
table_aux = int2str(aux);  
table = [];
for i=1:3:size(table_aux,2)
   table = [table table_aux(:,i)];
end

mCodes = table;

table = cell(1,2);
table{1} = mCodes;

bitsPerBlock = 16 + (N^2)*log2(M);
bitstream = repmat('0',[1,bitsPerBlock*length(Blocks)]);
k=1;
i=1;

while (k<=length(Blocks))
    
    a = Blocks{k}(:);
    y = qBlocks{k}(:);
    x(1,1) = min(a);
    x(2,1) = max(a);
    delta = getDelta(a,M);
    table{2} = getqValues(a,delta,N,M);
    
    for j=1:2
        bitstream(i:i+7) = dec2bin(x(j),8);
        i = i+8;
    end
    
    for j=1:N^2
        b = (y(j) == table{2});
        v = table{1}(b,:);
        bitstream(i:i+log2(M)-1) = v(1,:);
        i = i+log2(M);
    end
    k = k+1;
end

end