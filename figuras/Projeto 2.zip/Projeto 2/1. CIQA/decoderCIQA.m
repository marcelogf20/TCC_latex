function decoderCIQA(filename)
tic
[bitstream,m,n,M,N] = readBitstreamFromFile(filename);

nBlocks = ceil((m*n)/(N^2));
Blocks = cell(nBlocks,1);

aux = permn([0;1],log2(M));
table_aux = int2str(aux);  
table = [];
for i=1:3:size(table_aux,2)
   table = [table table_aux(:,i)];
end

mCodes = table;

table = cell(1,2);
table{1} = mCodes;

i = 1;
k=1;

bitsPerBlock = 16 + (N^2)*log2(M);

while(k <= nBlocks)

    for j=1:2
        x(j) = bin2dec(bitstream(i:i+7));
        i = i+8;
    end
    
    delta = getDelta(x,M);
    qValues = getqValues(x,delta,N,M);
    table{2} = qValues;
    
    for j=1:N^2
        a(j) = table{2}(bin2dec(bitstream(i: i + log2(M) - 1)) == bin2dec(table{1}));
        i = i + log2(M);
    end

    Blocks{k} = reshape(a,N,N);
    k = k+1;
end

outImg = getImageFromqBlocks(Blocks,m,n);

outFilename = [];

for i=1:length(filename)
    if(filename(i) == '_')
        break;
    else
        outFilename = [outFilename filename(i)];
    end
end

outFilename = strcat(outFilename, '_Uniform_Quantizer_Decoded_', int2str(M),'_',int2str(N),'.bmp');

imwrite(outImg,outFilename);
toc
end

