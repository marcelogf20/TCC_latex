function delta = getDelta(block,M)

a = block(:);
xmin = min(a);
xmax = max(a);

delta = (xmax - xmin)/M;

end