function out = isinrange(a,lower,upper)

out = a>=lower & a <=upper;

end