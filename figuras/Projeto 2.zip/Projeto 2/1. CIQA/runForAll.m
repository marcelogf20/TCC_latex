CIQA(2,4,'lena.bmp');
decoderCIQA('lena_Uniform_Quantizer_2_4');
CIQA(2,8,'lena.bmp');
decoderCIQA('lena_Uniform_Quantizer_2_8');
CIQA(2,16,'lena.bmp');
decoderCIQA('lena_Uniform_Quantizer_2_16')
CIQA(2,32,'lena.bmp');
decoderCIQA('lena_Uniform_Quantizer_2_32');

CIQA(4,4,'lena.bmp');
decoderCIQA('lena_Uniform_Quantizer_4_4')
CIQA(4,8,'lena.bmp');
decoderCIQA('lena_Uniform_Quantizer_4_8')
CIQA(4,16,'lena.bmp');
decoderCIQA('lena_Uniform_Quantizer_4_16')
CIQA(4,32,'lena.bmp');
decoderCIQA('lena_Uniform_Quantizer_4_32')


CIQA(8,4,'lena.bmp');
decoderCIQA('lena_Uniform_Quantizer_8_4')
CIQA(8,8,'lena.bmp');
decoderCIQA('lena_Uniform_Quantizer_8_8')
CIQA(8,16,'lena.bmp');
decoderCIQA('lena_Uniform_Quantizer_8_16')
CIQA(8,32,'lena.bmp');
decoderCIQA('lena_Uniform_Quantizer_8_32')

CIQA(16,4,'lena.bmp');
decoderCIQA('lena_Uniform_Quantizer_16_4')
CIQA(16,8,'lena.bmp');
decoderCIQA('lena_Uniform_Quantizer_16_8')
CIQA(16,16,'lena.bmp');
decoderCIQA('lena_Uniform_Quantizer_16_16')
CIQA(16,32,'lena.bmp');
decoderCIQA('lena_Uniform_Quantizer_16_32');

