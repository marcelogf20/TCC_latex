function qBlock = quantizeBlocksDecoder(Block,delta,N,M)

qBlock = zeros(size(Block));

    a = Block(:);
    xmin = min(a);
    xmax = max(a);
    
    limits(1,1) = 0;
    
    for j=2:(M)
        limits(1,j) = xmin + (j-1)*delta;
    end
    
    limits(1,j+1) = 255;
    
    qvalue = getqValue(xmin,xmax,limits(1,:));
    aux = ones(size(Block{i}))*-1;
    
    %qBlock = doit(Block,limits(1,:),qvalue);


end