function m = doit(Block,limitsx,qvaluex)

m = ones(size(Block))*-1;

for k=1:length(limitsx)-1
    m(Block>=limitsx(k) & Block<=limitsx(k+1)) = qvaluex(k);
end


end