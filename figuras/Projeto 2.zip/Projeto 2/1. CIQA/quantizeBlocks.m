function qBlocks = quantizeBlocks(Blocks,delta,N,M)

qBlocks = cell(size(Blocks));

for i=1:length(Blocks)
    a = Blocks{i}(:);
    xmin = min(a);
    xmax = max(a);
    
    limits(i,1) = 0;
    
    for j=2:(M)
        limits(i,j) = xmin + (j-1)*delta(i);
    end
    
    limits(i,j+1) = 255;
    
    qvalue = getqValue(xmin,xmax,limits(i,:));
    aux = ones(size(Blocks{i}))*-1;
    
    qBlocks{i} = doit(Blocks{i},limits(i,:),qvalue);
end

end