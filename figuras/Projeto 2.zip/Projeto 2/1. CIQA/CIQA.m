function CIQA(M,N,filename)
tic
img = imread(filename);
img = double(img);
m = size(img,1);
n = size(img,2);

Blocks = getBlocks(N,img);  %gera os blocos de tamanho NxN e os armazena em um cell array

nBlocks = ceil((m*n)/(N^2));
delta = zeros(nBlocks,1);

for i=1:length(Blocks)
   delta(i) = getDelta(Blocks{i},M);
end

qBlocks = quantizeBlocks(Blocks,delta,N,M);

bitstream = encode(M,N,Blocks,qBlocks);

writeBitstreamToFile(bitstream,filename,M,N,size(img,1),size(img,2));

toc
end