function outImg = getImageFromqBlocks(qBlocks,m,n) %m � o numero de linhas da imagem, n � o numero de colunas da imagem

outImg = ones(m,n,3)*-1;
k=1;

for i=1:m
    for j=1:n
        outImg(i,j,1) = qBlocks{k}(1);
        outImg(i,j,2) = qBlocks{k}(2);
        outImg(i,j,3) = qBlocks{k}(3);
        k = k + 1;
    end
end
  
outImg = uint8(outImg);
%imshow(outImg);
end