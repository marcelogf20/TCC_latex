function decoderCIMAP(filename)
tic
[bitstream,m,n,M,L] = readBitstreamFromFile(filename);

codeBook = cell(M,1);

i=1;

for z=1:M
    a = zeros(L,1);
    for j=1:L
        a(j) = bin2dec(bitstream(1,i:i+7));
        i = i+8;
    end
    codeBook{z} = a;
end

codeBook_matrix = zeros(length(codeBook),L);
for j = 1:length(codeBook)
    codeBook_matrix(j,1:end) = codeBook{j}';
end

k=1;
nBlocks = m*n;
Blocks = cell(nBlocks,1);

while(k<=nBlocks)
    I = bin2dec(bitstream(1,i:i+log2(M)-1)) + 1; %informa qual vetor do codebook devemos selecionar
    Blocks{k} = codeBook{I};
    i = i+log2(M);
    k=k+1;
end

outImg = getImageFromqBlocks(Blocks,m,n);

outFilename = [];

for i=1:length(filename)
    if(filename(i) == '_')
        break;
    else
        outFilename = [outFilename filename(i)];
    end
end

outFilename = strcat(outFilename, '_CIMAP_Decoded_', int2str(M),'.bmp');

imwrite(outImg,outFilename);
toc
end