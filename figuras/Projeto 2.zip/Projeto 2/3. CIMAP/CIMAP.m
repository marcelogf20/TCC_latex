function CIMAP(filename,M) %L: tamanho dos codevectors; M:tamanho do codebook
tic
L = 3;

img = imread(filename);
img = double(img);

m = size(img,1);
n = size(img,2);

Blocks = getBlocks(L,img);

[codeBook,clusters] = getCodeBook(Blocks,L,M);

for i=1:length(codeBook)
    codeBook{i} = round(codeBook{i});
end

qBlocks = VQ(Blocks,codeBook,clusters,m,n,L);

bitstream = encode(qBlocks,codeBook,L,M);

writeBitstreamToFile(bitstream,filename,M,L,m,n);
toc
end
                            