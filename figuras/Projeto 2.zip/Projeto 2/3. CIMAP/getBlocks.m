function Blocks = getBlocks(L,img)  %essa fun��o gera os blocos que ser�o quantizados

nBlocks =(size(img,1)*size(img,2));
Blocks = cell(nBlocks,1);

i=1;
k=1;
for i=1:size(img,1)
    for j=1:size(img,2)
        aux = img(i,j,:);
        Blocks{k} = aux(:);
        k = k + 1;
    end
end


end