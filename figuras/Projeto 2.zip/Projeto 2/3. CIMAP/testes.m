CIMAP('kodim15.png',16);
decoderCIMAP('kodim15_CIMAP_Quantizer_16');

CIMAP('kodim15.png',32);
decoderCIMAP('kodim15_CIMAP_Quantizer_32');

CIMAP('kodim15.png',64);
decoderCIMAP('kodim15_CIMAP_Quantizer_64');

CIMAP('kodim15.png',128);
decoderCIMAP('kodim15_CIMAP_Quantizer_128');

CIMAP('kodim15.png',256);
decoderCIMAP('kodim15_CIMAP_Quantizer_256');