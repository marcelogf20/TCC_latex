% FUNCTION codificaJPEG
% 
%  Codifica uma imagem com o JPEG em uma dada taxa espec�fica (ou o mais
%  pr�ximo disso).
%    
%  [ImageOut, PSNROut, RateOut] = codificaJPEG(ImageIn, filename, targetRate)
%      ImageIn:    Matriz da imagem a ser codificada
%      filename:   Nome do Arquivo
%      targetRate: taxa espec�fica em bits por pixel
%      ImageOut:   Matriz da imagem codificada
%      PSNROut:    psnr entre a imagem original e a imagem codificada
%      RateOut:    taxa da codifica��o mais pr�xima a targetRate 
%                  (em bits por pixel)
%
%  Exemplo - Codifica��o da Imagem CameraMan a 1 bit por pixel.
%     A = imread('cameraman.tif');
%     [ImageOut, PSNROut, RateOut] = codificaJPEG(A, 'cameracoded', 1);
%
function [ImageOut, PSNROut, RateOut] = codificaJPEG(ImageIn, filename, targetRate)

[h w c] = size(ImageIn);
npixels = h * w;

%Coloca o '.jpg' no nome se n�o tiver ainda.
if (strcmp(filename(end-3:end),'.jpg') == 0)
    filename = [filename '.jpg'];
end



lastQ = 150;
currQ = 50; 

q_vector = [];
rate_vector = [];

ok = 1;
while(ok == 1)
    imwrite(ImageIn,filename,'jpg','Quality',currQ);
    
    a = dir(filename);
    currRateBPP = (a.bytes * 8)/npixels;
    
    q_vector = [q_vector currQ];
    rate_vector = [rate_vector currRateBPP];
    
    disp(['Quality = ' num2str(currQ) ' - Rate = ' num2str(currRateBPP,'%2.2f') ' bpp']);
    
    deltaQ = abs(currQ - lastQ);
    if (deltaQ <= 1)
        ok = 0;
    else        
        lastQ = currQ;        
        if (currRateBPP > targetRate)
            if (currQ - round(deltaQ/2) > 0)
                currQ = currQ - round(deltaQ/2);            
            else
                currQ = 0;
            end
        else
            if (currQ + round(deltaQ/2) < 100)
                currQ = currQ + round(deltaQ/2);
            else
                currQ = 100;
            end
        end
    end
end

%Procura qual Q deu o valor mais parecido com o target Rate.
rate_error = abs(rate_vector - targetRate);
[~,idx] = min(rate_error);

currQ = q_vector(idx);
imwrite(ImageIn,filename,'jpg','Quality',currQ);
    
a = dir(filename);
currRateBPP = (a.bytes * 8)/npixels;

disp(['Chosen Quality = ' num2str(currQ) ' - Rate = ' num2str(currRateBPP,'%2.2f') ' bpp']);

ImageOut = imread(filename);
PSNROut = psnr(ImageIn,ImageOut);
RateOut = currRateBPP;